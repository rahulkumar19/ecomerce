package com.example.demo;

import com.example.demo.entities.PincodeServiceability;
import com.example.demo.repository.PincodeServiceabilityRepository;
import com.example.demo.service.PincodeServiceabilityService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PincodeServiceabilityServiceTest {

    @Autowired
    private PincodeServiceabilityService pincodeServiceabilityService;

    @Autowired
    private PincodeServiceabilityRepository pincodeServiceabilityRepository;

    @Test
    public void testCreatePincodeServiceability() {
        // Arrange
        String sourcePincode = "12345";
        String destinationPincode = "67890";
        String paymentMode = "COD";

        // Act
        Long serviceabilityId = pincodeServiceabilityService.createPincodeServiceability(sourcePincode, destinationPincode, paymentMode);

        // Assert
        assertNotNull(serviceabilityId);
        PincodeServiceability serviceability = pincodeServiceabilityRepository.findById(serviceabilityId).orElse(null);
        assertNotNull(serviceability);
        assertEquals(sourcePincode, serviceability.getSourcePincode());
        assertEquals(destinationPincode, serviceability.getDestinationPincode());
        assertEquals(paymentMode, serviceability.getPaymentMode());
    }

    // Add more test cases as needed
}
