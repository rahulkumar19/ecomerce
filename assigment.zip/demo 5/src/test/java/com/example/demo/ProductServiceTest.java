package com.example.demo;

import com.example.demo.entities.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductServiceTest {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductRepository productRepository;

    @Test
    public void testCreateProduct() {
        // Arrange
        String productName = "Laptop";
        int productInventory = 10;
        double productPrice = 999.99;
        String pickupAddress = "456 Tech Avenue";

        // Act
        Long productId = productService.createProduct(productName, productInventory, BigDecimal.valueOf(productPrice), pickupAddress, "787");

        // Assert
        assertNotNull(productId);
        Product product = productRepository.findById(productId).orElse(null);
        assertNotNull(product);
        assertEquals(productName, product.getName());
        assertEquals(productInventory, product.getInventory());
        assertEquals(pickupAddress, product.getPickupAddress());
    }

}

