package com.example.demo;

import com.example.demo.entities.Buyer;
import com.example.demo.repository.BuyerRepository;
import com.example.demo.service.BuyerService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BuyerServiceTest {

    @Autowired
    private BuyerService buyerService;

    @Autowired
    private BuyerRepository buyerRepository;

    @Test
    public void testCreateBuyer() {
        // Arrange
        String buyerName = "John Doe";
        String buyerAddress = "123 Main Street";

        // Act
        Long buyerId = buyerService.createBuyer(buyerName, buyerAddress, "123456");

        // Assert
        assertNotNull(buyerId);
        Buyer buyer = buyerRepository.findById(buyerId).orElse(null);
        assertNotNull(buyer);
        assertEquals(buyerName, buyer.getName());
        assertEquals(buyerAddress, buyer.getAddress());
    }

}

