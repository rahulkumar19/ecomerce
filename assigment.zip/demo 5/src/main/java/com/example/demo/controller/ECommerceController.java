package com.example.demo.controller;

import com.example.demo.request.BuyerRequest;
import com.example.demo.request.OrderRequest;
import com.example.demo.request.PincodeServiceabilityRequest;
import com.example.demo.request.ProductRequest;
import com.example.demo.service.BuyerService;
import com.example.demo.service.OrderService;
import com.example.demo.service.PincodeServiceabilityService;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ECommerceController {

    @Autowired
    private BuyerService buyerService;

    @Autowired
    private ProductService productService;

    @Autowired
    private PincodeServiceabilityService pincodeServiceabilityService;

    @Autowired
    private OrderService orderService;

    @PostMapping("/buyers")
    public ResponseEntity<?> createBuyer(@RequestBody BuyerRequest buyerRequest) {
        Long buyerId = buyerService.createBuyer(buyerRequest.getName(), buyerRequest.getAddress(), buyerRequest.getPincode());
        return new ResponseEntity<>("BuyerCreated with Id: "+buyerId, HttpStatus.CREATED);
    }

    @PostMapping("/products")
    public ResponseEntity<?> createProduct(@RequestBody ProductRequest productRequest) {
        Long productId = productService.createProduct(
                productRequest.getName(),
                productRequest.getInventory(),
                productRequest.getPrice(),
                productRequest.getPickupAddress(),
                productRequest.getPickupPincode()
        );
        return new ResponseEntity<>("product created with Id: "+productId, HttpStatus.CREATED);
    }

    @PostMapping("/pincode-serviceability")
    public ResponseEntity<Long> createPincodeServiceability(@RequestBody PincodeServiceabilityRequest request) {
        Long serviceabilityId = pincodeServiceabilityService.createPincodeServiceability(
                request.getSourcePincode(),
                request.getDestinationPincode(),
                request.getPaymentMode()
        );
        return new ResponseEntity<>(serviceabilityId, HttpStatus.CREATED);
    }

    @PostMapping("/orders")
    public ResponseEntity<String> createOrder(@RequestBody OrderRequest orderRequest) {
        try{
            String orderId = orderService.createOrder(
                    orderRequest.getBuyerId(),
                    orderRequest.getProductId(),
                    orderRequest.getQuantity(),
                    orderRequest.getPaymentMode()
            );

            return new ResponseEntity<>(orderId, HttpStatus.CREATED);

        }catch (Exception e){
            return new ResponseEntity<>(e.toString(), HttpStatus.BAD_REQUEST);
        }
    }
}

