package com.example.demo.repository;

import com.example.demo.entities.PincodeServiceability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface PincodeServiceabilityRepository extends JpaRepository<PincodeServiceability, Long> {

    @Query("SELECT ps FROM PincodeServiceability ps " +
            "WHERE ps.sourcePincode = :pickupAddress " +
            "AND ps.destinationPincode = :deliveryAddress")
    Optional<PincodeServiceability> findServiceability(
            @Param("pickupAddress") String pickupAddress,
            @Param("deliveryAddress") String deliveryAddress
    );

}
