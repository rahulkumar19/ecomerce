package com.example.demo.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderRequest {
    private String buyerId;
    private String productId;
    private int quantity;
    private String paymentMode;


    public OrderRequest() {
    }

    public OrderRequest(String buyerId, String productId, int quantity, String paymentMode) {
        this.buyerId = buyerId;
        this.productId = productId;
        this.quantity = quantity;
        this.paymentMode = paymentMode;
    }

}

