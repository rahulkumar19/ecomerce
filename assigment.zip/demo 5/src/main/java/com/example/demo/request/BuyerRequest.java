package com.example.demo.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BuyerRequest {
    private String name;
    private String address;
    private String pincode;


    public BuyerRequest() {
    }

    public BuyerRequest(String name, String address) {
        this.name = name;
        this.address = address;
    }

}

