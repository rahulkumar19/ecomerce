package com.example.demo.exceptions;

public class ProductOutOfStocck extends RuntimeException {
    public ProductOutOfStocck(String s) {
        super(s);
    }
}
