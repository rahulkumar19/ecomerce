package com.example.demo.service;

import com.example.demo.entities.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Long createProduct(String name, int inventory, BigDecimal price, String pickupAddress, String pickupPincode) {
        Product product = new Product();
        product.setName(name);
        product.setInventory(inventory);
        product.setPrice(price);
        product.setPickupAddress(pickupAddress);
        product.setPickupPincode(pickupPincode);

        Product savedProduct = productRepository.save(product);
        return savedProduct.getId();
    }

}

