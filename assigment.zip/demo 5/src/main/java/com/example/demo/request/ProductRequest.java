package com.example.demo.request;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class ProductRequest {
    private String name;
    private int inventory;
    private BigDecimal price;
    private String pickupAddress;
    private String pickupPincode;



    public ProductRequest() {
    }

    public ProductRequest(String name, int inventory, BigDecimal price, String pickupAddress) {
        this.name = name;
        this.inventory = inventory;
        this.price = price;
        this.pickupAddress = pickupAddress;
    }
}



