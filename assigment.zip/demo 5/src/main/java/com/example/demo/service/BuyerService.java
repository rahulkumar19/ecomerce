package com.example.demo.service;

import com.example.demo.exceptions.BuyerExistsException;
import com.example.demo.entities.Buyer;
import com.example.demo.repository.BuyerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BuyerService {

    @Autowired
    private BuyerRepository buyerRepository;

    public Long createBuyer(String name, String address, String pincode) throws BuyerExistsException {
        Buyer existingBuyer = buyerRepository.findByNameAndAddress(name, address);
        if (existingBuyer != null) {
            throw new BuyerExistsException("Buyer with the same name and address already exists");
        }


        // Return the ID of the newly created buyer
        Buyer buyer = new Buyer();
        buyer.setName(name);
        buyer.setAddress(address);
        buyer.setPincode(pincode);

        Buyer savedBuyer = buyerRepository.save(buyer);
        return savedBuyer.getId();
    }
}

