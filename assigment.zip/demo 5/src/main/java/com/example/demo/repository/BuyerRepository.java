package com.example.demo.repository;

import com.example.demo.entities.Buyer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyerRepository extends JpaRepository<Buyer, Long> {
    Buyer findByNameAndAddress(String name, String address);
}