package com.example.demo.service;

import com.example.demo.entities.PincodeServiceability;
import com.example.demo.repository.PincodeServiceabilityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PincodeServiceabilityService {

    @Autowired
    private PincodeServiceabilityRepository pincodeServiceabilityRepository;

    public Long createPincodeServiceability(String sourcePincode, String destinationPincode, String paymentMode) {
        PincodeServiceability serviceability = new PincodeServiceability();
        serviceability.setSourcePincode(sourcePincode);
        serviceability.setDestinationPincode(destinationPincode);
        serviceability.setPaymentMode(paymentMode);

        PincodeServiceability savedServiceability = pincodeServiceabilityRepository.save(serviceability);
        return savedServiceability.getId();
    }
}
