package com.example.demo.exceptions;

public class BuyerExistsException extends RuntimeException{
    public BuyerExistsException(String message) {
        super(message);
    }
}
