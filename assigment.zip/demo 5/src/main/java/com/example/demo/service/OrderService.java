package com.example.demo.service;

import com.example.demo.exceptions.OrderFailedException;
import com.example.demo.exceptions.ProductOutOfStocck;
import com.example.demo.entities.Buyer;
import com.example.demo.entities.OrderEntity;
import com.example.demo.entities.PincodeServiceability;
import com.example.demo.entities.Product;
import com.example.demo.repository.BuyerRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.PincodeServiceabilityRepository;
import com.example.demo.repository.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private BuyerRepository buyerRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private PincodeServiceabilityRepository pincodeServiceabilityRepository;

    @Transactional
    public synchronized String createOrder(String buyerId, String productId, int quantity, String paymentMode) throws EntityNotFoundException, OrderFailedException {
        // Retrieve Buyer, Product, and PincodeServiceability entities
        Buyer buyer = buyerRepository.findById(Long.valueOf(buyerId))
                .orElseThrow(() -> new EntityNotFoundException("Buyer not found with id: " + buyerId));

        Product product = productRepository.findById(Long.parseLong(productId))
                .orElseThrow(() -> new EntityNotFoundException("Product not found with id: " + productId));

        PincodeServiceability serviceability = getPincodeServiceability(product.getPickupPincode(), buyer.getPincode());

        // Validate orderEntity based on available inventory and pincode serviceability
        if (!isPincodeServiceable(serviceability, paymentMode)) {
            throw new OrderFailedException("OrderEntity failed because pincode is unserviceable");
        }

        if (product.getInventory() < quantity) {
            throw new ProductOutOfStocck("OrderEntity failed because product stock is insufficient");
        }

        // Create and save the OrderEntity entity
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setBuyerId(buyerId);
        orderEntity.setProductId(productId);
        orderEntity.setQuantity(quantity);
        orderEntity.setPaymentMode(paymentMode);
        orderEntity.setOrderId(generateOrderId());

        // Update product inventory
        product.setInventory(product.getInventory() - quantity);

        orderRepository.save(orderEntity);
        productRepository.save(product);

        return orderEntity.getOrderId();
    }

    private String generateOrderId() {
        String timestamp = LocalDateTime.now().toString().replace("-", "").replace(":", "").replace(".", "");
        String uuid = UUID.randomUUID().toString().replace("-", "");
        return "ORDER-" + timestamp + "-" + uuid;
    }

    private PincodeServiceability getPincodeServiceability(String pickupAddress, String deliveryAddress) {
        return pincodeServiceabilityRepository.findServiceability(deliveryAddress, pickupAddress)
                .orElseThrow(() -> new EntityNotFoundException("Pincode serviceability not found"));
    }

    private boolean isPincodeServiceable(PincodeServiceability serviceability, String paymentMode) {
        // Check if the given pincode serviceability supports the specified payment mode
        return serviceability.getPaymentMode().equalsIgnoreCase(paymentMode);
    }
}
