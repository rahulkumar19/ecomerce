package com.example.demo.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PincodeServiceabilityRequest {
    private String sourcePincode;
    private String destinationPincode;
    private String paymentMode;


    public PincodeServiceabilityRequest() {
    }

    public PincodeServiceabilityRequest(String sourcePincode, String destinationPincode, String paymentMode) {
        this.sourcePincode = sourcePincode;
        this.destinationPincode = destinationPincode;
        this.paymentMode = paymentMode;
    }

}

