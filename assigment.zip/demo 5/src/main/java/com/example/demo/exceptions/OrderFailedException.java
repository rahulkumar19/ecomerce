package com.example.demo.exceptions;

public class OrderFailedException extends Exception {
    public OrderFailedException(String s) {
        super(s);
    }
}
